function k=Circularity(A)
%A is input object in binary form
k=Perimeter(A)^2/area(A);
